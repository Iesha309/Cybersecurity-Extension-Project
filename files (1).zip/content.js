/**
 * PassGuard — content.js
 * ─────────────────────────────────────────────────────────────
 * Yeh script har website par automatically kaam karti hai.
 * Jab bhi koi password field milti hai, uske neeche
 * ek strength indicator dikhata hai — real time mein.
 * Authors: Aasma Azhar & Ayesha Siddiqa | Group #06
 */

"use strict";

// ── Common passwords ───────────────────────────────────────────────────────
const COMMON_PASSWORDS = new Set([
  "123456","password","123456789","12345678","12345","1234567",
  "password1","abc123","qwerty","111111","letmein","monkey",
  "1234567890","dragon","master","sunshine","iloveyou","admin",
  "welcome","login","pass","test","hello","pakistan","lahore",
  "karachi","islamabad","0000","1111","2222","123123","000000",
  "password123","passw0rd","p@ssword","p@ssw0rd","qwerty123",
]);

const KEYBOARD_SEQS = [
  "qwerty","qwertyuiop","asdfgh","asdfghjkl","zxcvbn",
  "1234567890","abcdefgh",
];

const ATTACK_SPEED = 1e12;

// ── Analyzer engine (same logic as popup.js) ───────────────────────────────
function charsetSize(pw) {
  let s = 0;
  if (/[a-z]/.test(pw)) s += 26;
  if (/[A-Z]/.test(pw)) s += 26;
  if (/\d/.test(pw))    s += 10;
  if (/[^a-zA-Z0-9]/.test(pw)) s += 32;
  return s || 1;
}

function calcEntropy(pw) {
  return pw.length * Math.log2(charsetSize(pw));
}

function formatCrack(secs) {
  if (secs < 1)        return "Instantly";
  if (secs < 60)       return `${secs.toFixed(0)} sec`;
  if (secs < 3600)     return `${(secs/60).toFixed(0)} min`;
  if (secs < 86400)    return `${(secs/3600).toFixed(0)} hrs`;
  if (secs < 2592000)  return `${(secs/86400).toFixed(0)} days`;
  if (secs < 31536000) return `${(secs/2592000).toFixed(0)} months`;
  if (secs < 3.154e12) return `${(secs/31536000).toFixed(0)} years`;
  return "Forever ∞";
}

function isCommon(pw)    { return COMMON_PASSWORDS.has(pw.toLowerCase()); }
function hasKeyboard(pw) {
  const l = pw.toLowerCase();
  return KEYBOARD_SEQS.some(s => l.includes(s) || l.includes([...s].reverse().join("")));
}
function hasRepeated(pw)    { return /(.)\1{3,}/.test(pw); }
function hasSequential(pw) {
  for (let i = 0; i < pw.length - 2; i++) {
    const a = pw.charCodeAt(i), b = pw.charCodeAt(i+1), c = pw.charCodeAt(i+2);
    if (b-a===1 && c-b===1) return true;
    if (a-b===1 && b-c===1) return true;
  }
  return false;
}

function scorePassword(pw) {
  if (!pw) return null;
  const entropy  = calcEntropy(pw);
  const crack    = Math.pow(2, entropy) / ATTACK_SPEED;
  let penalty    = 0;
  let tip        = "";

  if (isCommon(pw))      { penalty += 60; tip = "⚠ Bahut common password hai!"; }
  if (hasKeyboard(pw))   { penalty += 20; tip = tip || "⚠ Keyboard pattern hai (qwerty etc)"; }
  if (hasRepeated(pw))   { penalty += 15; tip = tip || "⚠ Repeating characters hain"; }
  if (hasSequential(pw)) { penalty += 15; tip = tip || "⚠ Sequential chars hain (123/abc)"; }
  if (pw.length < 8)     { penalty += 25; tip = tip || "⚠ Bahut chota hai — 8+ chars chahiye"; }
  else if (pw.length < 12){ penalty += 10; tip = tip || "💡 12+ chars use karo"; }

  if (!/[A-Z]/.test(pw)) penalty += 10;
  if (!/\d/.test(pw))    penalty += 10;
  if (!/[^a-zA-Z0-9]/.test(pw)) penalty += 10;

  const base  = Math.min(100, Math.floor(entropy * 1.6));
  const score = Math.max(0, base - penalty);
  const rating = score < 30 || isCommon(pw) ? "Weak"
               : score < 65 ? "Medium" : "Strong";

  if (!tip && rating === "Strong") tip = "✅ Strong password!";
  if (!tip && rating === "Medium") tip = "💡 Thoda aur strong karo";
  if (!tip && rating === "Weak")   tip = "⚠ Weak hai — improve karo";

  return { score, rating, crack: formatCrack(crack), tip };
}

// ── Colors ─────────────────────────────────────────────────────────────────
function ratingColor(rating) {
  return rating === "Weak"   ? "#f85149"
       : rating === "Medium" ? "#e3a008"
       :                       "#39d353";
}

// ── Create indicator element ───────────────────────────────────────────────
function createIndicator() {
  const wrap = document.createElement("div");
  wrap.className = "passguard-indicator";
  wrap.innerHTML = `
    <div class="pg-bar-track">
      <div class="pg-bar-fill" style="width:0%"></div>
    </div>
    <div class="pg-meta">
      <span class="pg-rating">Type karo…</span>
      <span class="pg-crack"></span>
    </div>
    <div class="pg-tip"></div>
  `;
  return wrap;
}

// ── Attach to a password field ─────────────────────────────────────────────
function attachToField(field) {
  // Avoid double-attaching
  if (field.dataset.passguardAttached) return;
  field.dataset.passguardAttached = "true";

  // Position indicator after the field
  const indicator = createIndicator();
  field.insertAdjacentElement("afterend", indicator);

  const bar    = indicator.querySelector(".pg-bar-fill");
  const rating = indicator.querySelector(".pg-rating");
  const crack  = indicator.querySelector(".pg-crack");
  const tip    = indicator.querySelector(".pg-tip");

  field.addEventListener("input", () => {
    const pw = field.value;
    if (!pw) {
      bar.style.width = "0%";
      rating.textContent = "Type karo…";
      rating.style.color = "#636e7b";
      crack.textContent  = "";
      tip.textContent    = "";
      return;
    }

    const r = scorePassword(pw);
    const color = ratingColor(r.rating);

    bar.style.width      = `${r.score}%`;
    bar.style.background = color;

    rating.textContent   = `${r.rating} — ${r.score}/100`;
    rating.style.color   = color;

    crack.textContent    = `⏱ Crack: ${r.crack}`;
    tip.textContent      = r.tip;
    tip.style.color      = color;
  });
}

// ── Scan page for password fields ──────────────────────────────────────────
function scanPage() {
  const fields = document.querySelectorAll("input[type='password']");
  fields.forEach(attachToField);
}

// Run on load
scanPage();

// Also watch for dynamically added fields (SPAs like Gmail, Facebook etc.)
const observer = new MutationObserver(() => scanPage());
observer.observe(document.body, { childList: true, subtree: true });
