/**
 * PassGuard Chrome Extension — popup.js
 * ─────────────────────────────────────────────────────────────
 * Python analyzer.py logic fully ported to JavaScript.
 * No server needed — everything runs locally in the extension.
 * Authors: Aasma Azhar & Ayesha Siddiqa | Group #06
 */

"use strict";

// ── Common passwords corpus (mirrors analyzer.py) ──────────────────────────
const COMMON_PASSWORDS = new Set([
  "123456","password","123456789","12345678","12345","1234567",
  "password1","abc123","qwerty","111111","letmein","monkey",
  "1234567890","dragon","master","sunshine","iloveyou","admin",
  "welcome","login","pass","test","hello","pakistan","lahore",
  "karachi","islamabad","0000","1111","2222","123123","000000",
  "password123","passw0rd","p@ssword","p@ssw0rd","qwerty123",
]);

// ── Keyboard sequences ─────────────────────────────────────────────────────
const KEYBOARD_SEQS = [
  "qwerty","qwertyuiop","asdfgh","asdfghjkl","zxcvbn",
  "1234567890","abcdefgh","abcdefghijklmnop",
];

// ── Attack speed: 1 trillion guesses/second ────────────────────────────────
const ATTACK_SPEED = 1e12;

// ── Charset sizes ──────────────────────────────────────────────────────────
function charsetSize(pw) {
  let size = 0;
  if (/[a-z]/.test(pw)) size += 26;
  if (/[A-Z]/.test(pw)) size += 26;
  if (/\d/.test(pw))    size += 10;
  if (/[^a-zA-Z0-9]/.test(pw)) size += 32;
  return size || 1;
}

// ── Entropy ────────────────────────────────────────────────────────────────
function calcEntropy(pw) {
  return pw.length * Math.log2(charsetSize(pw));
}

// ── Crack time ─────────────────────────────────────────────────────────────
function crackSeconds(entropy) {
  return Math.pow(2, entropy) / ATTACK_SPEED;
}

function formatCrack(secs) {
  if (secs < 1)              return "Instantly";
  if (secs < 60)             return `${secs.toFixed(1)} sec`;
  if (secs < 3600)           return `${(secs/60).toFixed(1)} min`;
  if (secs < 86400)          return `${(secs/3600).toFixed(1)} hrs`;
  if (secs < 2592000)        return `${(secs/86400).toFixed(1)} days`;
  if (secs < 31536000)       return `${(secs/2592000).toFixed(1)} months`;
  if (secs < 3.154e12)       return `${(secs/31536000).toFixed(1)} years`;
  if (secs < 3.154e19)       return `${(secs/3.154e9).toFixed(1)}B years`;
  return "Forever ∞";
}

// ── Pattern detectors ──────────────────────────────────────────────────────
function isCommon(pw)        { return COMMON_PASSWORDS.has(pw.toLowerCase()); }

function hasKeyboard(pw) {
  const lower = pw.toLowerCase();
  return KEYBOARD_SEQS.some(seq => lower.includes(seq) || lower.includes([...seq].reverse().join("")));
}

function hasRepeated(pw)     { return /(.)\1{3,}/.test(pw); }

function hasSequential(pw) {
  for (let i = 0; i < pw.length - 2; i++) {
    const a = pw.charCodeAt(i), b = pw.charCodeAt(i+1), c = pw.charCodeAt(i+2);
    if (b-a === 1 && c-b === 1) return true;
    if (a-b === 1 && b-c === 1) return true;
  }
  return false;
}

function isLeet(pw) {
  const map = {"@":"a","3":"e","!":"i","1":"l","0":"o","$":"s","5":"s","7":"t","8":"b"};
  const normalized = [...pw.toLowerCase()].map(c => map[c] || c).join("");
  return COMMON_PASSWORDS.has(normalized);
}

// ── Main scoring engine (mirrors Python score_password) ───────────────────
function scorePassword(pw) {
  if (!pw) return null;

  const length    = pw.length;
  const hasLower  = /[a-z]/.test(pw);
  const hasUpper  = /[A-Z]/.test(pw);
  const hasDigit  = /\d/.test(pw);
  const hasSymbol = /[^a-zA-Z0-9]/.test(pw);

  const entropy   = calcEntropy(pw);
  const crack     = crackSeconds(entropy);

  const patterns    = [];
  const suggestions = [];
  let   penalty     = 0;

  if (isCommon(pw)) {
    patterns.push("Common password");
    suggestions.push("This is one of the most-guessed passwords — change it immediately.");
    penalty += 60;
  }
  if (hasKeyboard(pw)) {
    patterns.push("Keyboard walk (e.g. qwerty)");
    suggestions.push("Avoid keyboard walks like 'qwerty' or 'asdfgh'.");
    penalty += 20;
  }
  if (hasRepeated(pw)) {
    patterns.push("Repeated characters (e.g. aaaa)");
    suggestions.push("Avoid repeating the same character 4+ times in a row.");
    penalty += 15;
  }
  if (hasSequential(pw)) {
    patterns.push("Sequential characters (e.g. abc, 123)");
    suggestions.push("Avoid sequences like 'abc' or '123'.");
    penalty += 15;
  }
  if (!isCommon(pw) && isLeet(pw)) {
    patterns.push("Leet-speak of a common word");
    suggestions.push("Replacing letters with symbols (p@ssw0rd) is a known attack technique.");
    penalty += 30;
  }

  if (length < 8) {
    suggestions.push("Use at least 8 characters — NIST recommends 12+.");
    penalty += 25;
  } else if (length < 12) {
    suggestions.push("Consider 12+ characters for significantly better security.");
    penalty += 10;
  }

  if (!hasLower)  { suggestions.push("Add lowercase letters (a–z).");   penalty += 10; }
  if (!hasUpper)  { suggestions.push("Add uppercase letters (A–Z).");   penalty += 10; }
  if (!hasDigit)  { suggestions.push("Add digits (0–9).");              penalty += 10; }
  if (!hasSymbol) { suggestions.push("Add symbols (!@#$%^&*) for extra entropy."); penalty += 10; }

  if (suggestions.length === 0) {
    suggestions.push("Great password! Store it in a password manager like Bitwarden.");
  }

  const base  = Math.min(100, Math.floor(entropy * 1.6));
  const score = Math.max(0, base - penalty);
  const rating = score < 30 || isCommon(pw) ? "Weak"
               : score < 65                 ? "Medium"
               :                              "Strong";

  return {
    score, rating, entropy: entropy.toFixed(1),
    crack: formatCrack(crack), length,
    hasLower, hasUpper, hasDigit, hasSymbol,
    patterns, suggestions,
  };
}

// ── Color helpers ──────────────────────────────────────────────────────────
function ratingColor(rating) {
  return rating === "Weak" ? "#f85149" : rating === "Medium" ? "#e3a008" : "#39d353";
}

// ── DOM refs ───────────────────────────────────────────────────────────────
const pwInput     = document.getElementById("pwInput");
const eyeBtn      = document.getElementById("eyeBtn");
const barFill     = document.getElementById("barFill");
const ratingLabel = document.getElementById("ratingLabel");
const scoreLabel  = document.getElementById("scoreLabel");
const metrics     = document.getElementById("metrics");
const mEntropy    = document.getElementById("mEntropy");
const mCrack      = document.getElementById("mCrack");
const mLen        = document.getElementById("mLen");
const secChecks   = document.getElementById("secChecks");
const chkLower    = document.getElementById("chkLower");
const chkUpper    = document.getElementById("chkUpper");
const chkDigit    = document.getElementById("chkDigit");
const chkSymbol   = document.getElementById("chkSymbol");
const secPatterns = document.getElementById("secPatterns");
const patternTags = document.getElementById("patternTags");
const secSuggestions = document.getElementById("secSuggestions");
const suggList    = document.getElementById("suggList");

// ── UI update ──────────────────────────────────────────────────────────────
function updateUI(result) {
  if (!result) {
    barFill.style.width = "0%";
    ratingLabel.textContent = "—";
    ratingLabel.className   = "";
    scoreLabel.textContent  = "—/100";
    metrics.style.display   = "none";
    secChecks.style.display = "none";
    secPatterns.style.display = "none";
    secSuggestions.style.display = "none";
    return;
  }

  const { score, rating, entropy, crack, length,
          hasLower, hasUpper, hasDigit, hasSymbol,
          patterns, suggestions } = result;

  // Bar
  barFill.style.width      = `${Math.min(score, 100)}%`;
  barFill.style.background = ratingColor(rating);

  // Labels
  ratingLabel.textContent = rating;
  ratingLabel.className   = rating.toLowerCase();
  scoreLabel.textContent  = `${score}/100`;

  // Metrics
  metrics.style.display  = "flex";
  mEntropy.textContent   = `${entropy} bits`;
  mCrack.textContent     = crack;
  mLen.textContent       = `${length} chars`;

  // Checks
  secChecks.style.display = "block";
  setChk(chkLower,  hasLower,  "a–z");
  setChk(chkUpper,  hasUpper,  "A–Z");
  setChk(chkDigit,  hasDigit,  "0–9");
  setChk(chkSymbol, hasSymbol, "!@#");

  // Patterns
  patternTags.innerHTML = "";
  if (patterns.length === 0) {
    patternTags.innerHTML = '<span class="no-patterns">✓ No patterns found</span>';
  } else {
    patterns.forEach(p => {
      const span = document.createElement("span");
      span.className   = "ptag";
      span.textContent = p;
      patternTags.appendChild(span);
    });
  }
  secPatterns.style.display = "block";

  // Suggestions
  suggList.innerHTML = "";
  suggestions.forEach(s => {
    const li = document.createElement("li");
    li.textContent = s;
    suggList.appendChild(li);
  });
  secSuggestions.style.display = "block";
}

function setChk(el, pass, label) {
  el.textContent = label;
  el.classList.toggle("pass", pass);
  el.classList.toggle("fail", !pass);
}

// ── Events ─────────────────────────────────────────────────────────────────
let timer = null;
pwInput.addEventListener("input", () => {
  clearTimeout(timer);
  timer = setTimeout(() => updateUI(scorePassword(pwInput.value)), 280);
});

eyeBtn.addEventListener("click", () => {
  const hidden = pwInput.type === "password";
  pwInput.type = hidden ? "text" : "password";
  eyeBtn.textContent = hidden ? "🙈" : "👁";
});

// Focus on open
pwInput.focus();
